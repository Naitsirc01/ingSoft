create view data_view as
select `persona`.`rut`            AS `rut_persona`,
       `persona2`.`fecha_ingreso` AS `fecha_ingreso`,
       `persona2`.`fecha_egreso`  AS `fecha_egreso`,
       `c`.`nombre`               AS `nombre_carrera`,
       `u`.`nombre`               AS `universidad_carrera`,
       `tp`.`nombre`              AS `postgrado_nombre`,
       `p`.`fecha_obtencion`      AS `fecha_postgrado`,
       `u2`.`nombre`              AS `universidad_postgrado`,
       `r`.`nombre`               AS `nombre_rubro`,
       `empresa`.`nombre`         AS `nombre_tipo_empresa`,
       `c2`.`fecha_inicio`        AS `cargo_inicio`,
       `c2`.`fecha_termino`       AS `cargo_termino`,
       `c2`.`sueldo`              AS `sueldo_cargo`,
       `cargo`.`nombre`           AS `nombre_cargo`,
       `a`.`nombre`               AS `nombre_area`
from ((((((((((((`homestead`.`personas` `persona` join `homestead`.`carrera_persona` `persona2` on ((`persona`.`id` = `persona2`.`persona_id`))) join `homestead`.`carreras` `c` on ((`persona2`.`carrera_id` = `c`.`id`))) join `homestead`.`universidades` `u` on ((`c`.`universidad_id` = `u`.`id`))) join `homestead`.`postgrados` `p` on ((`persona`.`id` = `p`.`persona_id`))) join `homestead`.`tipo_postgrados` `tp` on ((`p`.`tipoPostgrado_id` = `tp`.`id`))) join `homestead`.`universidades` `u2` on ((`p`.`universidad_id` = `u2`.`id`))) join `homestead`.`empresas` `e` on ((`persona`.`id` = `e`.`persona_id`))) join `homestead`.`rubros` `r` on ((`e`.`rubro_id` = `r`.`id`))) join `homestead`.`tipo_empresas` `empresa` on ((`e`.`tipo_empresa_id` = `empresa`.`id`))) join `homestead`.`cargos` `c2` on ((`e`.`id` = `c2`.`empresa_id`))) join `homestead`.`nivel_cargos` `cargo` on ((`c2`.`nivel_cargo_id` = `cargo`.`id`)))
       join `homestead`.`areas` `a` on ((`c2`.`area_id` = `a`.`id`)));

